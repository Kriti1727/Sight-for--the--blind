# SIGHT-For-the-Blind

Ever thought how is the life of a blind person, their life is full of risk. They can't even walk alone through a busy street or through a park. They shall need some assistance from others. They are also curious about the beauty of the world, they should have will be the excitement to explore the world, and to be aware of what is happening in front of them. Even though they can find their own things without anyone's need. So,How we solve this?

Simply, Sight is a pair of smart glasses for the blind. By using Sight, a person can able to know what is going on in front of him.

for more deatils :- https://www.hackster.io/diykerala/sight-for-the-blind-c1e1b9
